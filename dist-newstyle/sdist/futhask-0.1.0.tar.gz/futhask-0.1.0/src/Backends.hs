module Backends where

data Backend = C | OpenCL | Cuda
