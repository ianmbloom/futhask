# Changelog for futhask

## Unreleased changes
